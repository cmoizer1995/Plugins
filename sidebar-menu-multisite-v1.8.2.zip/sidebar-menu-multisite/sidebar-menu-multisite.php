<?php
/*
Plugin Name: Sidebar Menu (Multisite Compatible)
Description: Custom sidebar menu styled like Elliott Hudson, with multisite support and cleanup routine.
Version: 1.8.2
Author: Connor Moizer (with ChatGPT assistance)
*/

if (!defined('ABSPATH')) exit;

// Cleanup old versions
function sidebar_menu_cleanup_old_versions() {
    $plugins = get_option('active_plugins');
    foreach ($plugins as $plugin) {
        if (strpos($plugin, 'sidebar-menu') !== false && $plugin !== plugin_basename(__FILE__)) {
            deactivate_plugins($plugin);
        }
    }
}
register_activation_hook(__FILE__, 'sidebar_menu_cleanup_old_versions');

// Multisite compatibility
function sidebar_menu_multisite_setup($network_wide) {
    if (is_multisite() && $network_wide) {
        global $wpdb;
        $blog_ids = $wpdb->get_col("SELECT blog_id FROM $wpdb->blogs");
        foreach ($blog_ids as $blog_id) {
            switch_to_blog($blog_id);
            sidebar_menu_cleanup_old_versions();
            restore_current_blog();
        }
    } else {
        sidebar_menu_cleanup_old_versions();
    }
}
register_activation_hook(__FILE__, 'sidebar_menu_multisite_setup');

// Enqueue styles
function sidebar_menu_enqueue_styles() {
    wp_enqueue_style('sidebar-menu-style', plugin_dir_url(__FILE__) . 'style.css');
}
add_action('wp_enqueue_scripts', 'sidebar_menu_enqueue_styles');
?>
